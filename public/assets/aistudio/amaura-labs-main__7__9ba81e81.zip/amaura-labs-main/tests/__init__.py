"""
Amaura Test Suite
"""
