"""
Web visualization dashboard package
"""
